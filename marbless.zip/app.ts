import express, { Application } from 'express';
import * as path from 'path';
import * as readline from 'readline';


const app: Application = express();

// Function to display the matrix
function displayMatrix(matrix: string[][]): void {
    for (const row of matrix) {
        console.log(row.join(' '));
    }
    console.log();
}


// Initialize the matrix
const initialMatrix: string[][] = [
    ['A', 'B', 'G', 'C', 'F'],
    ['D', 'A', 'M', 'N', 'M'],
    ['B', 'D', 'E', 'F', 'O'],
    ['F', 'M', 'C', 'C', 'C'],
    ['K', 'L', 'M', 'M', 'M']
];

// Function to update the matrix after a word is formed
function updateMatrix(matrix: string[][], word: string): void {
    for (const letter of word) {
        const colIndex = matrix[matrix.length - 1].indexOf(letter);
        for (let row = matrix.length - 2; row >= 0; row--) {
            matrix[row + 1][colIndex] = matrix[row][colIndex];
        }
        matrix[0][colIndex] = ' ';
    }
}

// Create a readline interface for user input
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Set up EJS as the view engine
app.set('view engine', 'ejs');

// Main game loop
function playGame() {
    const matrix: string[][] = initialMatrix.map(row => [...row]); // Create a copy of the initial matrix
    let score = 0;

    app.get('/', (req, res) => {
        const sanitizedMatrix = matrix.map(row => row.join(' ')).join('\n');
        res.render('index', { matrix: sanitizedMatrix });
    });

    const port = process.env.PORT || 8888;
    app.listen(port, () => {
        console.log(`Server is listening on port ${port}`);
        askForWord();
    });

    function askForWord() {
        displayMatrix(matrix);
        rl.question("Enter a word using the last row's letters: ", (word) => {
            const sanitizedWord = word.trim().toUpperCase();

            if (!sanitizedWord.match(/^[A-Z]+$/)) {
                console.log("Invalid input. Enter a valid word.");
                askForWord();
                return;
            }

            if (sanitizedWord.split('').every(letter => matrix[matrix.length - 1].includes(letter))) {
                score += sanitizedWord.length;
                updateMatrix(matrix, sanitizedWord);
            } else {
                console.log("Invalid word. Use only letters from the last row.");
            }

            // Continue playing or end the game based on your own conditions
            askForWord();
        });
    }

    askForWord();
}

// Start the game
playGame();
